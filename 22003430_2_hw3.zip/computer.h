/*
* Title: computer.h
* Author: Mustafa Cem Gülümser
* ID: 22003430
* Section: 2
* Assignment: 3
* Description: Computer class header file
*/

struct computer {

    public:
    computer();
    computer( int number);
    int compNumber;
    bool isWorking;
    int processingTime;

};