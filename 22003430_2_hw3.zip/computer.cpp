#include "computer.h"
/*
* Title: computer.cpp
* Author: Mustafa Cem Gülümser
* ID: 22003430
* Section: 2
* Assignment: 3
* Description: Computer class source code file
*/
computer::computer() {
    isWorking = false;
    processingTime = 0;
}
computer::computer( int number) {
    compNumber = number;
    isWorking = false;
    processingTime = 0;
}